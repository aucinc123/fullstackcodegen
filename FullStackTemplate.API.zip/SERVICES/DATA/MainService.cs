﻿using Dapper;
using $safeprojectname$.Models;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace $safeprojectname$.Services.Data
{
    public class MainService
    {
        private readonly AppSettings appSettings;

        public MainService(AppSettings appSettings)
        {
            this.appSettings = appSettings;
        }

        public async Task<int> GetValueFromStoredProc()
        {
            using (SqlConnection cn = new SqlConnection(appSettings.DBConnection))
            {
                int id = await cn.ExecuteScalarAsync<int>("dbo.uspGetValueFromStoredProc",
                                                            new
                                                            {
                                                            },
                                                            commandType: CommandType.StoredProcedure);
                return id;
            }
        }
    }
}
