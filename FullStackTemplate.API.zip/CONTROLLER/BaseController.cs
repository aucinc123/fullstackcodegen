﻿using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Controller
{
    [ApiController]
    public class BaseController : ControllerBase
    {
        public BaseController()
        {
        }
    }
}