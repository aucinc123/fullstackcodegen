﻿using $safeprojectname$.Services.Data;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace $safeprojectname$.Controller
{
    [Produces("application/json")]
    [ApiController]
    [Route("api/main")]
    public class MainController : BaseController
    {
        private readonly MainService mainService;

        public MainController(MainService mainDataStore)
        {
            this.mainService = mainDataStore;
        }

        [HttpGet("healthCheck")]
        public IActionResult GetHealth()
        {
            return Ok("Ah, Ha, Ha, Ha, Stayin' Alive! Stayin' Alive!");
        }

        [HttpGet("valueFromStoredProc")]
        public async Task<IActionResult> GetValueFromStoredProc()
        {
            var value = await this.mainService.GetValueFromStoredProc();
            return Ok(value);
        }
    }
}